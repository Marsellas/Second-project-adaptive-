$(function() {
	
	$(".toggle-mnu").click(function() {
			$(this).toggleClass("on");
			$(".hidden-nav").slideToggle();
			return false;
		});

	incrementalNumber();

});

